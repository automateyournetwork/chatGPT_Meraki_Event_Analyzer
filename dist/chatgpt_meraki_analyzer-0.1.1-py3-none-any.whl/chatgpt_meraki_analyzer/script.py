from .chatgpt_meraki_analyzer import cli
def run():
    cli()